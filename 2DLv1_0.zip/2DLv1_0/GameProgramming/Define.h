#ifndef DEFINE_H
#define DEFINE_H

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600


#endif
